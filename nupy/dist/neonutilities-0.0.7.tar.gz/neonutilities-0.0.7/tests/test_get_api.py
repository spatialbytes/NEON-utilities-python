# -*- coding: utf-8 -*-
"""
Created on Thu Aug 31 12:41:04 2023

@author: bhass

Tests (Branches):
    1. internet connection handling
        a. check_connection fails
        b. check_connection succeeds but status code is 200

    2. token applied as expected
        a. token is None
        b. token is not None
        
        additional checks:
        - check for type? - token should be a string
        - check for token validity - with a token, the x-ratelimit-limit should be > 200
        
    3. url validity
        - non-200 status code returns none
        - 200 status code enters into rate-limit check

    4. api rate limit 
        a. reached  - wait & retry
        b. not reached - exits out of loop

resources
https://py-pkgs.org/05-testing
https://opensource.com/article/21/9/unit-test-python
https://semaphoreci.com/community/tutorials/getting-started-with-mocking-in-python

"""

import requests
import unittest
from unittest.mock import patch
import pytest
from neonutilities import get_api


unlimited_token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiJ9.eyJhdWQiOiJodHRwczovL2RhdGEubmVvbnNjaWVuY2Uub3JnL2FwaS92MC8iLCJzdWIiOiJiaGFzc0BiYXR0ZWxsZWVjb2xvZ3kub3JnIiwic2NvcGUiOiJyYXRlOnVubGltaXRlZCByZWFkOnJlbGVhc2VzIHJlYWQ6cmVsZWFzZXMtbGF0ZXN0IiwiaXNzIjoiaHR0cHM6Ly9kYXRhLm5lb25zY2llbmNlLm9yZy8iLCJleHAiOjE4MDE1MDcxNDEsImlhdCI6MTY0MzgyNzE0MSwiZW1haWwiOiJiaGFzc0BiYXR0ZWxsZWVjb2xvZ3kub3JnIn0.Takgb6N0IxEKJSJmUMylE-XAwKn4FjPliHAsFV5qbAe-Qw-7J5K_jylFloCjEC1sTpvEFLr2u0diVm7dMS_Nxg'
limited_token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiJ9.eyJhdWQiOiJodHRwczovL2RhdGEubmVvbnNjaWVuY2Uub3JnL2FwaS92MC8iLCJzdWIiOiJiaGFzc0BiYXR0ZWxsZWVjb2xvZ3kub3JnIiwic2NvcGUiOiJyYXRlOnB1YmxpYyIsImlzcyI6Imh0dHBzOi8vZGF0YS5uZW9uc2NpZW5jZS5vcmcvIiwiZXhwIjoxODUxNjEzMDYzLCJpYXQiOjE2OTM5MzMwNjMsImVtYWlsIjoiYmhhc3NAYmF0dGVsbGVlY29sb2d5Lm9yZyJ9.ZNOPk_xXFVEnUhPYcPESbTrCnuVv1hSN2kCEMhQWLqCkmC-irD_CxPHa7TCDAZEZuCI0vfNcIxVBJ7dkI93gEQ'
invalid_token = 'test'

valid_url = 'https://data.neonscience.org/api/v0/samples/classes?sampleTag=MCRA.SS.20230425.POM.1'
valid_url2 = 'https://data.neonscience.org/api/v0/products/DP1.00001.001'
invalid_url = 'https://data.neonscience.org/api/v0/samples/classes?sampleTag=SITE'
# url_requiring_token = 'https://data.neonscience.org/api/v0/data/DP3.30006.001/WREF/2021-07?release=LATEST'

# mock tests - unit tests should not be making actual API calls


class TestGetApi(unittest.TestCase):

    @patch('requests.get')
    def test_internet_connection_with_other_url(self, mock_get):
        mock_get.side_effect = requests.exceptions.ConnectionError()

        def side_effect(url):
            if url == 'https://data.neonscience.org/':
                return requests.Response()
            else:
                raise ValueError(
                    'The connection url https://data.neonscience.org/ has been modified.')

        mock_get.side_effect = side_effect
        self.assertFalse(get_api(valid_url))

    @patch('requests.get')
    def test_check_bad_connection(self, mock_get):
        #     Test that the get_api() check_connection returns None if request returns a ConnectionError
        #     """
        mock_get.side_effect = ConnectionError
        response = get_api(valid_url)
        self.assertIsNone(response)

    @patch('requests.get')
    def test_check_connection_invalid_status_code(self, mock_get):
        #     Test that the get_api() check_connection returns None if request returns a ConnectionError
        #     """
        mock_get.return_value.status_code = 400
        response = get_api(valid_url)
        self.assertIsNone(response)

    @patch('time.sleep', return_value=None)
    @patch('requests.get')
    def test_rate_limit_reached_retry(self, mock_get, mock_sleep):
        #     Test that the get_api() check_connection returns None if request returns a ConnectionError
        #     """
        mock_get.return_value.headers['x-ratelimit-remaining'] = 0
        mock_sleep.return_value = False
        response = get_api(valid_url)
        # self.assertIsNone(response)
        mock_sleep.assert_called_once()

        #     response = get_api(api_url=valid_url, token=None)
        #     assert response.status_code == 200


if __name__ == '__main__':
    unittest.main()

# 1. internet connection handling
#     a. check_connection fails
#     b. check_connection succeeds but status code is 200


# def test_check_connection_fails():
    #     Test that the get_api() function returns None if check_connection cannot be generated.
    #     """
    #     response = get_api(api_url=valid_url, token=None)
    #     assert response.status_code == 200

    # def test_valid_url():
    #     """
    #     Test that the get_api() function returns a response object when the URL is valid.
    #     """
    #     response = get_api(api_url=valid_url, token=None)
    #     assert response.status_code == 200

    # def test_invalid_url():
    #     """
    #     Test that the get_api() function returns None when the URL is invalid.
    #     """
    #     with pytest.raises(Exception) as exception:
    #         response = get_api(api_url=invalid_url, token=None)
    #     assert str(
    #         exception.value) == 'No response. Failed to establish a new connection.'

    # # def test_invalid_token():
    #     # if a token is provided the rate limit should be 1000 (>200)

    # # Check token, if included
    # if token:
    #     #     check_token_validity(token)
    #     check_token = requests.get(
    #         'https://data.neonscience.org/api/v0/products/DP1.00001.001', token)

    #     if 'x-ratelimit-limit' in dict(check_token.headers).keys():
    #         ratelimit = dict(check_token.headers)['x-ratelimit-limit']
    #         if int(ratelimit) == 200:
    #             print('Token is not valid, API request burst limit set to 200. Refer to https://data.neonscience.org/data-api/rate-limiting/ for more information.')
    #             if input("Do you want to continue with the download? (y/n) ") != "y":
    #                 print('Exiting get_api')
    #                 return

    # def test_get_api_rate_limit_reached():
    #     """
    #     Test that the get_api() function returns None when the URL is invalid.
    #     """
    # for i in range(200):
    #     response = get_api('https://data.neonscience.org/api/v0/products/DP1.00001.001','test')

    # @pytest.mark.skipif(
    #     'x-ratelimit-limit' not in dict(get_api(api_url='https://data.neonscience.org/api/v0/samples/classes?sampleTag=MCRA.SS.20230425.POM.1',token=None).headers.keys()),
    #     reason="API does not have rate limiting")
    # def test_get_api_rate_limit_exceeded():
    #     """
    #     Test that the get_api() function returns None if the rate limit is exceeded.
    #     """
    #     response = get_api(api_url='https://data.neonscience.org/api/v0/samples/classes?sampleTag=MCRA.SS.20230425.POM.1',token=None)
    #     assert response is None

    # def test_required_token_missing():
    #     """
    #     Test that the get_api() function returns when authentication is required
    #     but not provided
    #     """
    #     with pytest.raises(Exception) as exception:
    #         response = get_api(api_url=url_requiring_token, token=None)
    #     assert str(
    #         exception.value) == 'No response. Failed to establish a new connection.'

    # def test_required_token_valid():
    #     """
    #     Test that the get_api() function returns a valid response when a token is
    #     required and provided
    #     """
    #     response = get_api(api_url=url_requiring_token, token=valid_token)
    #     assert response.status_code == 200
